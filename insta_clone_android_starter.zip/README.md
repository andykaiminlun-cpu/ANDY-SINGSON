# Custom Instagram-style Android App (Starter)

This project contains:
- `backend/`: Express + MongoDB Atlas + JWT authentication + Cloudinary photo uploads
- `mobile/`: Expo React Native app with register/login, feed, image posting, likes, comments

## Important
This is a starter project, not a production-audited social network. Before public launch, add rate limiting, moderation/reporting, password reset, stronger validation, and production logging.

## Part A — Backend setup from an Android phone
1. Open GitHub Codespaces in your phone browser: https://github.com/codespaces
2. Create/open a GitHub repository and start a Codespace.
3. Upload/extract this project into the Codespace, or upload the `backend` folder.
4. In the terminal:
   ```bash
   cd backend
   npm install
   cp .env.example .env
   ```
5. Create a MongoDB Atlas database at https://www.mongodb.com/atlas and copy its connection string into `MONGODB_URI` in `.env`.
   - Replace `<db_password>` with your database user's password.
   - In Atlas Network Access, use a suitable IP access setup for your host. Avoid leaving unrestricted access enabled permanently.
6. Create a Cloudinary account at https://cloudinary.com/ and copy cloud name, API key, and API secret into `.env`.
7. Set a long random `JWT_SECRET` in `.env`.
8. Start the backend:
   ```bash
   npm run dev
   ```
9. In Codespaces, use the **Ports** panel to make port `5000` accessible. For mobile testing, set visibility to **Public** only if necessary and only while you understand that the API is internet-accessible. Copy the forwarded HTTPS URL.

## Part B — Mobile app using Expo Snack
1. Open https://snack.expo.dev/ in your phone browser.
2. Create a new Snack and replace `App.js` with `mobile/App.js` from this project.
3. Add dependencies in Snack if prompted:
   - `expo-image-picker`
   - `@react-native-async-storage/async-storage`
4. In `mobile/App.js`, replace `https://YOUR-CODESPACE-PORT-5000.app.github.dev` with your actual forwarded HTTPS URL.
5. Preview with Expo Go. Sign up with a test account.

## API endpoints
- `GET /api/health`
- `POST /api/auth/register` `{ "username": "...", "email": "...", "password": "..." }`
- `POST /api/auth/login` `{ "email": "...", "password": "..." }`
- `GET /api/posts`
- `POST /api/posts` (Bearer token; multipart fields `image`, `caption`, optional `location`)
- `PATCH /api/posts/:id/like` (Bearer token)
- `POST /api/posts/:id/comments` `{ "text": "..." }` (Bearer token)

## Local vs cloud
`mongodb://127.0.0.1:27017/...` only works when MongoDB is running in the same environment. For this phone-first workflow, use MongoDB Atlas instead.
