require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const cloudinary = require("cloudinary").v2;

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET;

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, trim: true, minlength: 2, maxlength: 24, unique: true },
  email: { type: String, required: true, trim: true, lowercase: true, unique: true },
  passwordHash: { type: String, required: true },
  avatarUrl: { type: String, default: "" },
}, { timestamps: true });

const postSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  username: { type: String, required: true },
  userImage: { type: String, default: "" },
  imageUrl: { type: String, required: true },
  caption: { type: String, default: "", maxlength: 2200 },
  location: { type: String, default: "", maxlength: 120 },
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  comments: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    username: { type: String, required: true },
    text: { type: String, required: true, maxlength: 500 },
    createdAt: { type: Date, default: Date.now }
  }],
}, { timestamps: true });

const User = mongoose.model("User", userSchema);
const Post = mongoose.model("Post", postSchema);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.mimetype)) {
      return cb(new Error("Only JPG, PNG, or WEBP images are allowed."));
    }
    cb(null, true);
  }
});

function makeToken(user) {
  return jwt.sign({ userId: user._id.toString() }, JWT_SECRET, { expiresIn: "7d" });
}

async function auth(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : "";
    if (!token) return res.status(401).json({ message: "Please log in first." });
    const payload = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(payload.userId);
    if (!user) return res.status(401).json({ message: "Account not found." });
    req.user = user;
    next();
  } catch (_err) {
    return res.status(401).json({ message: "Invalid or expired token." });
  }
}

function safeUser(user) {
  return { id: user._id, username: user.username, email: user.email, avatarUrl: user.avatarUrl };
}

function formatPost(post, viewerId) {
  const likedByMe = post.likes.some(id => id.toString() === viewerId);
  return {
    id: post._id,
    username: post.username,
    userImage: post.userImage,
    imageUrl: post.imageUrl,
    caption: post.caption,
    location: post.location,
    likesCount: post.likes.length,
    likedByMe,
    comments: post.comments.map(c => ({
      id: c._id, username: c.username, text: c.text, createdAt: c.createdAt
    })),
    createdAt: post.createdAt
  };
}

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "custom-social-backend" }));

app.post("/api/auth/register", async (req, res, next) => {
  try {
    const username = String(req.body.username || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    if (!/^[a-zA-Z0-9_.]{2,24}$/.test(username)) {
      return res.status(400).json({ message: "Username must be 2–24 characters (letters, numbers, _ or .)." });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ message: "Enter a valid email address." });
    }
    if (password.length < 8) return res.status(400).json({ message: "Password must be at least 8 characters." });
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await User.create({ username, email, passwordHash });
    res.status(201).json({ token: makeToken(user), user: safeUser(user) });
  } catch (err) {
    if (err.code === 11000) return res.status(409).json({ message: "That username or email is already registered." });
    next(err);
  }
});

app.post("/api/auth/login", async (req, res, next) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      return res.status(401).json({ message: "Incorrect email or password." });
    }
    res.json({ token: makeToken(user), user: safeUser(user) });
  } catch (err) { next(err); }
});

app.get("/api/auth/me", auth, (req, res) => res.json({ user: safeUser(req.user) }));

app.get("/api/posts", async (req, res, next) => {
  try {
    const viewerId = req.headers.authorization?.startsWith("Bearer ")
      ? (() => { try { return jwt.verify(req.headers.authorization.slice(7), JWT_SECRET).userId; } catch { return ""; } })()
      : "";
    const posts = await Post.find().sort({ createdAt: -1 }).limit(100);
    res.json(posts.map(p => formatPost(p, viewerId)));
  } catch (err) { next(err); }
});

app.post("/api/posts", auth, upload.single("image"), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ message: "Choose a photo to upload." });
    if (!process.env.CLOUDINARY_CLOUD_NAME || !process.env.CLOUDINARY_API_KEY || !process.env.CLOUDINARY_API_SECRET) {
      return res.status(500).json({ message: "Image storage is not configured on the server." });
    }
    const imageUrl = await new Promise((resolve, reject) => {
      const stream = cloudinary.uploader.upload_stream(
        { folder: "custom-social/posts", resource_type: "image" },
        (error, result) => error ? reject(error) : resolve(result.secure_url)
      );
      stream.end(req.file.buffer);
    });
    const post = await Post.create({
      user: req.user._id,
      username: req.user.username,
      userImage: req.user.avatarUrl,
      imageUrl,
      caption: String(req.body.caption || "").trim().slice(0, 2200),
      location: String(req.body.location || "").trim().slice(0, 120)
    });
    res.status(201).json(formatPost(post, req.user._id.toString()));
  } catch (err) { next(err); }
});

app.patch("/api/posts/:id/like", auth, async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid post ID." });
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found." });
    const id = req.user._id;
    const alreadyLiked = post.likes.some(userId => userId.equals(id));
    if (alreadyLiked) post.likes.pull(id);
    else post.likes.addToSet(id);
    await post.save();
    res.json(formatPost(post, id.toString()));
  } catch (err) { next(err); }
});

app.post("/api/posts/:id/comments", auth, async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid post ID." });
    const text = String(req.body.text || "").trim();
    if (!text || text.length > 500) return res.status(400).json({ message: "Comment must be 1–500 characters." });
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found." });
    post.comments.push({ user: req.user._id, username: req.user.username, text });
    await post.save();
    res.status(201).json(formatPost(post, req.user._id.toString()));
  } catch (err) { next(err); }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  if (err instanceof multer.MulterError) return res.status(400).json({ message: "Image is too large or invalid." });
  if (err.message?.includes("Only JPG")) return res.status(400).json({ message: err.message });
  res.status(500).json({ message: "Server error. Check the backend logs." });
});

if (!JWT_SECRET) {
  console.error("Missing JWT_SECRET. Create backend/.env using .env.example.");
  process.exit(1);
}

mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log("Connected to MongoDB");
    app.listen(PORT, "0.0.0.0", () => console.log(`API listening on port ${PORT}`));
  })
  .catch(err => {
    console.error("Could not connect to MongoDB:", err.message);
    process.exit(1);
  });
