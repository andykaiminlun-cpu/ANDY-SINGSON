import React, { useEffect, useState } from "react";
import {
  ActivityIndicator, Alert, FlatList, Image, KeyboardAvoidingView,
  Platform, SafeAreaView, ScrollView, StatusBar, StyleSheet,
  Text, TextInput, TouchableOpacity, View
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as ImagePicker from "expo-image-picker";

// Replace with your GitHub Codespaces forwarded HTTPS URL.
// Example: https://your-codespace-5000.app.github.dev
const API_URL = "https://YOUR-CODESPACE-PORT-5000.app.github.dev";

const C = {
  bg: "#101018", panel: "#191925", panel2: "#222233",
  text: "#F7F4FF", muted: "#AAA7BD", pink: "#FF4D8D",
  purple: "#A78BFA", border: "#302D43", danger: "#FF6B78"
};

export default function App() {
  const [token, setToken] = useState("");
  const [user, setUser] = useState(null);
  const [mode, setMode] = useState("login");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [screen, setScreen] = useState("home");
  const [photo, setPhoto] = useState(null);
  const [caption, setCaption] = useState("");
  const [location, setLocation] = useState("");
  const [commentDrafts, setCommentDrafts] = useState({});

  useEffect(() => {
    (async () => {
      const saved = await AsyncStorage.getItem("social_token");
      if (saved) {
        setToken(saved);
        try {
          const r = await fetch(`${API_URL}/api/auth/me`, { headers: { Authorization: `Bearer ${saved}` } });
          const data = await r.json();
          if (r.ok) setUser(data.user);
          else await AsyncStorage.removeItem("social_token");
        } catch (_e) {}
      }
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    if (user) refreshPosts();
  }, [user]);

  async function request(path, options = {}) {
    const headers = { ...(options.headers || {}) };
    if (token) headers.Authorization = `Bearer ${token}`;
    if (options.body && !(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
    const response = await fetch(`${API_URL}${path}`, { ...options, headers });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.message || "Something went wrong.");
    return data;
  }

  async function authenticate() {
    if (!email.trim() || !password) return Alert.alert("Missing details", "Enter your email and password.");
    if (mode === "register" && !username.trim()) return Alert.alert("Missing username", "Choose a username.");
    setBusy(true);
    try {
      const data = await request(`/api/auth/${mode === "register" ? "register" : "login"}`, {
        method: "POST",
        body: JSON.stringify({ username: username.trim(), email: email.trim(), password })
      });
      setToken(data.token);
      setUser(data.user);
      await AsyncStorage.setItem("social_token", data.token);
      setPassword("");
    } catch (e) { Alert.alert("Could not sign in", e.message); }
    finally { setBusy(false); }
  }

  async function refreshPosts() {
    try { setPosts(await request("/api/posts")); }
    catch (e) { Alert.alert("Feed error", `${e.message}\n\nCheck your API URL and backend status.`); }
  }

  async function pickPhoto() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) return Alert.alert("Permission needed", "Allow photo access to select a post image.");
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"], allowsEditing: true, quality: 0.85, aspect: [4, 5]
    });
    if (!result.canceled) setPhoto(result.assets[0]);
  }

  async function createPost() {
    if (!photo) return Alert.alert("Choose a photo", "Select an image first.");
    setBusy(true);
    try {
      const form = new FormData();
      form.append("caption", caption);
      form.append("location", location);
      form.append("image", {
        uri: photo.uri,
        name: photo.fileName || "upload.jpg",
        type: photo.mimeType || "image/jpeg"
      });
      await request("/api/posts", { method: "POST", body: form });
      setPhoto(null); setCaption(""); setLocation(""); setScreen("home");
      await refreshPosts();
    } catch (e) { Alert.alert("Upload failed", e.message); }
    finally { setBusy(false); }
  }

  async function toggleLike(postId) {
    try {
      const updated = await request(`/api/posts/${postId}/like`, { method: "PATCH" });
      setPosts(old => old.map(p => p.id === postId ? updated : p));
    } catch (e) { Alert.alert("Like failed", e.message); }
  }

  async function addComment(postId) {
    const text = (commentDrafts[postId] || "").trim();
    if (!text) return;
    try {
      const updated = await request(`/api/posts/${postId}/comments`, {
        method: "POST", body: JSON.stringify({ text })
      });
      setPosts(old => old.map(p => p.id === postId ? updated : p));
      setCommentDrafts(old => ({ ...old, [postId]: "" }));
    } catch (e) { Alert.alert("Comment failed", e.message); }
  }

  async function logout() {
    await AsyncStorage.removeItem("social_token");
    setToken(""); setUser(null); setPosts([]); setScreen("home");
  }

  if (loading) return <View style={s.center}><ActivityIndicator color={C.pink} size="large" /></View>;

  if (!user) return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" />
      <KeyboardAvoidingView style={s.authWrap} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <View style={s.brandMark}><Text style={s.brandGlyph}>✦</Text></View>
        <Text style={s.brand}>LUMI<Text style={{ color: C.pink }}>.</Text></Text>
        <Text style={s.tagline}>Your moments. Your people.</Text>
        <Text style={s.authTitle}>{mode === "login" ? "Welcome back" : "Create your account"}</Text>
        {mode === "register" && <TextInput placeholder="Username" placeholderTextColor={C.muted} autoCapitalize="none" value={username} onChangeText={setUsername} style={s.input} />}
        <TextInput placeholder="Email address" placeholderTextColor={C.muted} autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail} style={s.input} />
        <TextInput placeholder="Password (8+ characters)" placeholderTextColor={C.muted} secureTextEntry value={password} onChangeText={setPassword} style={s.input} />
        <TouchableOpacity style={s.primary} onPress={authenticate} disabled={busy}>
          {busy ? <ActivityIndicator color="#fff" /> : <Text style={s.primaryText}>{mode === "login" ? "Log in" : "Sign up"}</Text>}
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setMode(mode === "login" ? "register" : "login")} style={s.switchRow}>
          <Text style={s.muted}>{mode === "login" ? "New to Lumi? " : "Already have an account? "}<Text style={s.link}>{mode === "login" ? "Create account" : "Log in"}</Text></Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" />
      <View style={s.topbar}>
        <TouchableOpacity onPress={() => setScreen("home")}><Text style={s.brandSmall}>LUMI<Text style={{ color: C.pink }}>.</Text></Text></TouchableOpacity>
        <View style={s.topActions}>
          <TouchableOpacity onPress={() => setScreen("create")} style={s.topIcon}><Text style={s.topIconText}>＋</Text></TouchableOpacity>
          <TouchableOpacity onPress={logout} style={s.avatarMini}><Text style={s.avatarText}>{user.username?.[0]?.toUpperCase() || "U"}</Text></TouchableOpacity>
        </View>
      </View>

      {screen === "create" ? (
        <ScrollView contentContainerStyle={s.createWrap} keyboardShouldPersistTaps="handled">
          <Text style={s.screenTitle}>Create a post</Text>
          <TouchableOpacity onPress={pickPhoto} style={s.photoPicker}>
            {photo ? <Image source={{ uri: photo.uri }} style={s.previewImage} /> :
              <><Text style={s.pickIcon}>▧</Text><Text style={s.pickTitle}>Choose a photo</Text><Text style={s.muted}>JPG, PNG or WEBP · up to 8 MB</Text></>}
          </TouchableOpacity>
          <TextInput placeholder="Write a caption..." placeholderTextColor={C.muted} multiline value={caption} onChangeText={setCaption} style={[s.input, s.captionInput]} />
          <TextInput placeholder="Add location (optional)" placeholderTextColor={C.muted} value={location} onChangeText={setLocation} style={s.input} />
          <TouchableOpacity style={s.primary} onPress={createPost} disabled={busy}>
            {busy ? <ActivityIndicator color="#fff" /> : <Text style={s.primaryText}>Share post</Text>}
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setScreen("home")} style={s.cancel}><Text style={s.muted}>Cancel</Text></TouchableOpacity>
        </ScrollView>
      ) : (
        <FlatList
          data={posts}
          keyExtractor={item => item.id}
          refreshing={false}
          onRefresh={refreshPosts}
          contentContainerStyle={posts.length ? s.feed : s.emptyFeed}
          ListHeaderComponent={<View style={s.feedHeading}><Text style={s.screenTitle}>Discover</Text><Text style={s.muted}>A little life, shared beautifully.</Text></View>}
          ListEmptyComponent={<View style={s.empty}><Text style={s.emptyEmoji}>✦</Text><Text style={s.postTitle}>Your feed starts here</Text><Text style={s.muted}>Be the first to share a moment.</Text><TouchableOpacity style={s.primarySmall} onPress={() => setScreen("create")}><Text style={s.primaryText}>Create a post</Text></TouchableOpacity></View>}
          renderItem={({ item }) => (
            <View style={s.postCard}>
              <View style={s.postHeader}>
                <View style={s.avatar}><Text style={s.avatarText}>{item.username?.[0]?.toUpperCase() || "U"}</Text></View>
                <View style={{ flex: 1 }}>
                  <Text style={s.username}>{item.username}</Text>
                  {!!item.location && <Text style={s.location}>{item.location}</Text>}
                </View>
                <Text style={s.more}>•••</Text>
              </View>
              <Image source={{ uri: item.imageUrl }} style={s.postImage} resizeMode="cover" />
              <View style={s.postBody}>
                <View style={s.actionRow}>
                  <TouchableOpacity onPress={() => toggleLike(item.id)} style={s.actionButton}>
                    <Text style={[s.heart, item.likedByMe && { color: C.pink }]}>{item.likedByMe ? "♥" : "♡"}</Text>
                  </TouchableOpacity>
                  <Text style={s.actionGlyph}>○</Text>
                  <Text style={s.actionGlyph}>↗</Text>
                  <View style={{ flex: 1 }} />
                  <Text style={s.likes}>{item.likesCount} likes</Text>
                </View>
                {!!item.caption && <Text style={s.caption}><Text style={s.username}>{item.username} </Text>{item.caption}</Text>}
                {item.comments?.slice(-3).map(c => <Text key={c.id} style={s.comment}><Text style={s.username}>{c.username} </Text>{c.text}</Text>)}
                <View style={s.commentRow}>
                  <TextInput
                    placeholder="Add a comment..."
                    placeholderTextColor={C.muted}
                    value={commentDrafts[item.id] || ""}
                    onChangeText={value => setCommentDrafts(old => ({ ...old, [item.id]: value }))}
                    style={s.commentInput}
                  />
                  <TouchableOpacity onPress={() => addComment(item.id)}><Text style={s.postLink}>Post</Text></TouchableOpacity>
                </View>
              </View>
            </View>
          )}
        />
      )}
      <View style={s.bottomNav}>
        <TouchableOpacity onPress={() => setScreen("home")} style={s.navItem}><Text style={s.navGlyph}>⌂</Text><Text style={s.navLabel}>Home</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => setScreen("create")} style={s.navItem}><Text style={s.navGlyph}>＋</Text><Text style={s.navLabel}>Create</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => Alert.alert(user.username, user.email)} style={s.navItem}><Text style={s.navGlyph}>◎</Text><Text style={s.navLabel}>Profile</Text></TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  center: { flex: 1, backgroundColor: C.bg, alignItems: "center", justifyContent: "center" },
  authWrap: { flex: 1, justifyContent: "center", padding: 26 },
  brandMark: { alignSelf: "center", width: 62, height: 62, borderRadius: 22, backgroundColor: C.panel2, borderWidth: 1, borderColor: C.border, alignItems: "center", justifyContent: "center", marginBottom: 12 },
  brandGlyph: { color: C.pink, fontSize: 34 },
  brand: { color: C.text, fontSize: 38, fontWeight: "900", letterSpacing: 4, textAlign: "center" },
  tagline: { color: C.muted, textAlign: "center", marginTop: 6, marginBottom: 38 },
  authTitle: { color: C.text, fontSize: 23, fontWeight: "800", marginBottom: 18 },
  input: { backgroundColor: C.panel, borderColor: C.border, borderWidth: 1, borderRadius: 14, paddingHorizontal: 15, paddingVertical: 14, color: C.text, marginBottom: 12, fontSize: 15 },
  primary: { backgroundColor: C.pink, padding: 15, borderRadius: 14, alignItems: "center", marginTop: 4 },
  primaryText: { color: "#fff", fontWeight: "800", fontSize: 15 },
  switchRow: { alignItems: "center", padding: 20 },
  muted: { color: C.muted, fontSize: 13 },
  link: { color: C.purple, fontWeight: "700" },
  topbar: { height: 58, paddingHorizontal: 17, borderBottomWidth: 1, borderBottomColor: C.border, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  brandSmall: { color: C.text, fontSize: 24, fontWeight: "900", letterSpacing: 2 },
  topActions: { flexDirection: "row", alignItems: "center", gap: 14 },
  topIcon: { width: 35, height: 35, borderRadius: 12, backgroundColor: C.panel2, alignItems: "center", justifyContent: "center" },
  topIconText: { color: C.text, fontSize: 27, lineHeight: 30 },
  avatarMini: { width: 34, height: 34, borderRadius: 17, backgroundColor: C.purple, alignItems: "center", justifyContent: "center" },
  avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: C.panel2, borderWidth: 2, borderColor: C.pink, alignItems: "center", justifyContent: "center", marginRight: 10 },
  avatarText: { color: C.text, fontWeight: "800", fontSize: 15 },
  screenTitle: { color: C.text, fontSize: 25, fontWeight: "900", marginBottom: 4 },
  feedHeading: { paddingHorizontal: 16, paddingTop: 18, paddingBottom: 15 },
  feed: { paddingBottom: 14 },
  emptyFeed: { flexGrow: 1, paddingBottom: 14 },
  empty: { alignItems: "center", justifyContent: "center", paddingHorizontal: 25, paddingVertical: 55 },
  emptyEmoji: { color: C.pink, fontSize: 44, marginBottom: 12 },
  postTitle: { color: C.text, fontSize: 18, fontWeight: "800", marginBottom: 7 },
  primarySmall: { backgroundColor: C.pink, paddingVertical: 11, paddingHorizontal: 18, borderRadius: 12, marginTop: 18 },
  postCard: { marginHorizontal: 12, marginBottom: 18, backgroundColor: C.panel, borderWidth: 1, borderColor: C.border, borderRadius: 18, overflow: "hidden" },
  postHeader: { flexDirection: "row", alignItems: "center", padding: 12 },
  username: { color: C.text, fontWeight: "800" },
  location: { color: C.muted, fontSize: 11, marginTop: 2 },
  more: { color: C.muted, letterSpacing: 2, paddingHorizontal: 6 },
  postImage: { width: "100%", aspectRatio: 0.88, backgroundColor: C.panel2 },
  postBody: { paddingHorizontal: 13, paddingBottom: 12 },
  actionRow: { flexDirection: "row", alignItems: "center", paddingTop: 9, paddingBottom: 5, gap: 12 },
  actionButton: { paddingRight: 2 },
  heart: { color: C.text, fontSize: 31, lineHeight: 34 },
  actionGlyph: { color: C.text, fontSize: 27 },
  likes: { color: C.text, fontWeight: "800", fontSize: 12 },
  caption: { color: C.text, fontSize: 13, lineHeight: 19, marginTop: 3 },
  comment: { color: C.muted, fontSize: 12, marginTop: 5, lineHeight: 17 },
  commentRow: { flexDirection: "row", alignItems: "center", marginTop: 9, borderTopWidth: 1, borderTopColor: C.border, paddingTop: 7 },
  commentInput: { flex: 1, color: C.text, paddingVertical: 6, fontSize: 13 },
  postLink: { color: C.purple, fontWeight: "800", paddingLeft: 8 },
  createWrap: { padding: 18, paddingBottom: 30 },
  photoPicker: { height: 280, borderRadius: 18, borderWidth: 1, borderColor: C.border, borderStyle: "dashed", backgroundColor: C.panel, alignItems: "center", justifyContent: "center", marginTop: 16, marginBottom: 16, overflow: "hidden" },
  pickIcon: { color: C.pink, fontSize: 48, marginBottom: 10 },
  pickTitle: { color: C.text, fontSize: 17, fontWeight: "800", marginBottom: 6 },
  previewImage: { width: "100%", height: "100%" },
  captionInput: { minHeight: 95, textAlignVertical: "top" },
  cancel: { alignItems: "center", padding: 15 },
  bottomNav: { height: 63, borderTopWidth: 1, borderTopColor: C.border, backgroundColor: C.bg, flexDirection: "row", alignItems: "center", justifyContent: "space-around" },
  navItem: { alignItems: "center", justifyContent: "center", minWidth: 70 },
  navGlyph: { color: C.text, fontSize: 25, lineHeight: 28 },
  navLabel: { color: C.muted, fontSize: 10, marginTop: 2 }
});
